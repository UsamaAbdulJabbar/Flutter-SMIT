
void main() {
/*Q.1: Create two integer variables length and breadth and assign values then check if they are square values or rectangle values.
ie: if both values are equal then it's square otherwise rectangle. */

  int length = 10;
  int breadth = 10;

  if (length == breadth) {
    print("This is Square");
  } else {
    print("This is Rectangle");
  }

}
