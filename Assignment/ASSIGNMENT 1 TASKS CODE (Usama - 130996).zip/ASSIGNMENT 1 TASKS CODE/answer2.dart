void main(){

    //Q.2: Take two variables and store age then using if/else condition to determine oldest and youngest among them.

  int age = 25;
  if (age < 30) {
    print("You are young enjoy your life... ");
  } else {
    print("Your are Old Now");
  }
}