void main() {
// Q.6: Write a program to check whether an alphabet is a vowel or consonant.

  String alphbat = "n";

  if (alphbat != "a" &&
      alphbat != "e" &&
      alphbat != "i" &&
      alphbat != "o" &&
      alphbat != "u") {
    print("This is Consonant");
  } else {
    print("This Is Vowel");
  }
}
