void main() {
  //Q12: Write a program to convert Celsius  to Fahrenheit .i.e: Temperature in degrees Fahrenheit (°F) = (Temperature in degrees Celsius (°C) * 9/5) + 32

  double celcTemp = 47;
  double fehrenTemp = (celcTemp * 9 / 5) + 32;
  print("The temperature in Fahrenheit is: $fehrenTemp°F");
}
